 <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="search.php">
              <i class="material-icons">search</i>
              <p>Google Search Collection</p>
            </a>
          </li>
		  <li class="nav-item active  ">
            <a class="nav-link" href="searchcollection.php">
              <i class="material-icons">search</i>
              <p>Collected Data</p>
            </a>
          </li>
		  <li class="nav-item active  ">
            <a class="nav-link" href="#">
              <i class="material-icons">search</i>
              <p>Data Pre-Processing</p>
            </a>
          </li>
		  <li class="nav-item active  ">
            <a class="nav-link" href="#">
              <i class="material-icons">search</i>
              <p>Similarity Indentification</p>
            </a>
          </li>
		  <li class="nav-item active  ">
            <a class="nav-link" href="#">
              <i class="material-icons">search</i>
              <p>Page Ranking</p>
            </a>
          </li>
		  <li class="nav-item active  ">
            <a class="nav-link" href="#">
              <i class="material-icons">search</i>
              <p>Snippet Optimization</p>
            </a>
          </li>
		  <li class="nav-item active  ">
            <a class="nav-link" href="../index.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
        </ul> 