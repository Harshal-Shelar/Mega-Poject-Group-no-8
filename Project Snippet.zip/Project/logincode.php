<?php

$txtusername=$_POST['txtusername'];
$txtpassword=$_POST['txtpassword'];

	if($txtusername === "admin" && $txtpassword === "admin")
	{
		header("Location: admin/search.php");
	}
	else
	{
		header("Location:login.php");
	}
?>