<?php

    include("DBClass.php");
    $db = new DBClass();
    $query = "SELECT * FROM preprocessdata";
    $result = $db->executeQuery($query);
  ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Snippet Visualization System
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo">
        <a href="" class="simple-text logo-normal">
         Snippet Visualization 
        </a>
      </div>
      <div class="sidebar-wrapper">
		<?php include("menus.php"); ?>
      </div>
    </div>
    <div class="main-panel">
      <br /><br />
		<div class="col-lg-12" style="background-color:white;">
      <b><h3>Pre-Processed Data</h3></b>
      <?php
        $query = "SELECT * FROM rawdata";
        $resultRaw = $db->executeQuery($query);
        echo "Raw Data Count : " . mysqli_num_rows($resultRaw) . "&nbsp;&nbsp; | &nbsp;&nbsp;";
        echo "Pre-Processed Data Count : " . mysqli_num_rows($result);
      ?>
      <div class="row form-inline">
      <div class="col-lg-6">
      <form action="preprocess.php" method="GET">
          <input type="hidden" value="preprocess" name="action" />
        <input type="submit" class="btn btn-danger" value="Pre-Process Remaining Raw Data" />
        </form>
      
</div>
<div class="col-lg-6">
      <form action="preprocess.php" method="GET">
      <input type="hidden" value="stop" name="action" />
        <input type="submit" class="btn btn-success" value="Stop Pre-Processing" />
        </form>
</div>
</div>
      <table class="table table-bordered">
        <tr>
          <td>No</td>
          <td>Title</td>
          <td>Url</td>
          <td>Description</td>
        </tr>
        <?php
          $count = 1;
          while($row = mysqli_fetch_array($result))
          {
            echo "<tr>";
            echo "<td>" . $count . "</td>";
            echo "<td>" . $row['pre_title'] . "</td>";
            echo "<td>" . $row['pre_url'] . "</td>";
            echo "<td>" . $row['pre_description'] . "</td>";
            echo "</tr>";
            $count++;
          }
        ?>
      </table>
		</div>
    </div>
	
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="../assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="../assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
  <script src="../assets/demo/demo.js"></script>
</body>
<?php

    function preprocessData($dataToProcess)
    {
        return $dataToProcess;
    }

    if(isset($_GET['action']))
        {
            if($_GET['action'] == "preprocess")
            {
                $query = "SELECT * FROM rawdata WHERE id NOT IN(SELECT rawid FROM preprocessdata)";
                
                $result = $db->executeQuery($query);
                while($row = mysqli_fetch_array($result))
                {
                    $rawid = $row['id'];
                    $title = $row['title'];
                    $url = $row['url'];
                    $description = $row['description'];
                    
                    $title = preprocessData($title);
                    $description = preprocessData($description);

                    $title = str_replace("'", "''", $title);
                    $url = str_replace("'", "''", $url);
                    $description = str_replace("'", "''", $description);

                    $query = "INSERT INTO preprocessdata(rawid, pre_title, pre_url, pre_description) ";
                    $query .= "VALUES(" . $rawid . ", '" . $title . "', '" . $url . "', '" . $description . "')";

                    $db->executeQuery($query);
                }
            }
        }
?>


</html>