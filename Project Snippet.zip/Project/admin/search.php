<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Snippet Visualization System
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <link href="../assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <link href="../assets/demo/demo.css" rel="stylesheet" />

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo">
        <a href="" class="simple-text logo-normal">
         Snippet Visualization 
        </a>
      </div>
      <div class="sidebar-wrapper">
		<?php include("menus.php"); ?>
      </div>
    </div>
    <div class="main-panel">
      <br /><br /> <br /><br />
		<div class="col-lg-12">
			<div id="googleSearch" class="container" style="overflow-y:scroll; height:500px;">
        <?php include("googlesearch.php")?>
      </div>
			<input type="button" id="btnSave" class="btn btn-primary" value="Collect URLs" />
      <div id="sample">
      </div>
		</div>
    </div>	
  </div>
  <script type="text/javascript">
    $(document).ready(function() {
        $('#btnSave').click(function() {

          var divArray = document.getElementsByClassName("gsc-webResult gsc-result");
          var titles = [];
          var urls = [];
          var texts = [];
          for (var i = 0; i < divArray.length; i++) {
            var titleArray = divArray[i].getElementsByClassName("gs-title");
            var urlArray = divArray[i].getElementsByClassName("gs-visibleUrl-long");
            var textArray = divArray[i].getElementsByClassName("gs-bidi-start-align gs-snippet");
            for (var j = 0; j < titleArray.length; j++) {
              if(titleArray[j].innerText != null)
              {
                var title = titleArray[j].innerText;
                var addToTitle = true;
                for(var x = 0; x < titles.length; x++)
                {
                  if(titles[i] == title)
                      addToTitle = false;
                }
                if(addToTitle)
                  titles[i] = title;
              }        
            }

            for (var j = 0; j < urlArray.length; j++) {
              if(urlArray[j].innerText != null)
              {
                var url = urlArray[j].innerText;
                var addToURL = true;
                for(var x = 0; x < urls.length; x++)
                {
                  if(urls[i] == url)
                      addToURL = false;
                }
                if(addToURL)
                {
                  urls[i] = url;
                }
              }        
            }
            for (var j = 0; j < textArray.length; j++) {
              if(textArray[j].innerText != null)
              {
                var text = textArray[j].innerText;
                var addToText = true;
                for(var x = 0; x < texts.length; x++)
                {
                  if(texts[i] == url)
                      addToText = false;
                }
                if(addToText)
                {
                  texts[i] = text;
                }
              }        
            }
          }
          var sTitles = "", sUrls = "", sTexts = "";
          for(var i = 0; i < texts.length; i++)
          {
            if(i == 0)
            {
              sTitles = titles[i];
              sUrls = urls[i];
              sTexts = texts[i];
            }
            else{
              sTitles += "$$$$" + titles[i];
              sUrls += "$$$$" + urls[i];
              sTexts += "$$$$" + texts[i];
            }
          }

          $.ajax({
                  type: 'POST',
                  url: 'saveData.php',
                  data: {
                      'titles': sTitles,
                      'urls': sUrls,
                      'texts': sTexts
                  },
                  success: function(html) {
                    alert("Data Saved to Database");                      
                  }
              });
        });
    });
  </script>
</body>

</html>