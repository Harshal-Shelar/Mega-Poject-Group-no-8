<?php
class DBClass {
 function executeQuery($query)
   {
	   $con=mysqli_connect("localhost", "snippet", "root", "shelar");
       $result = mysqli_query($con, $query);       
       return $result;
   }
}