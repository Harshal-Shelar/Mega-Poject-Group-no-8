<?php

    include("DBClass.php");
    $db = new DBClass();
    $titles = explode("$$$$", $_REQUEST['titles']);
    $urls = explode("$$$$", $_REQUEST['urls']);
    $texts = explode("$$$$", $_REQUEST['texts']);

    for($i = 0; $i < sizeof($titles); $i++)
    {
        $title = $titles[$i];
        $url = $urls[$i];
        $text = $texts[$i];

        $title = str_replace("'", "''", $title);
        $url = str_replace("'", "''", $url);
        $text = str_replace("'", "''", $text);

        $query = "INSERT INTO rawdata(title, url, description)  ";
        $query .= "VALUES('" . $title . "', '" . $url . "', '" . $text . "')";
        $db->executeQuery($query);
    }

    echo "Success";
?>